#!/bin/bash
java -Xms1024M -Xmx1024M -jar initrelicdb.jar "$@"